import java.util.*;

// Contact class to store contact details
class Contact {
    String name;
    String phoneNumber;
    String email;

    public Contact(String name, String phoneNumber, String email) {
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.email = email;
    }

    @Override
    public String toString() {
        return "Name: " + name + ", Phone: " + phoneNumber + ", Email: " + email;
    }
}

// Node class for the Binary Search Tree (BST)
class TreeNode {
    Contact contact;
    TreeNode left, right;

    public TreeNode(Contact contact) {
        this.contact = contact;
        this.left = this.right = null;
    }
}

// Contact Management System using a Binary Search Tree (BST)
public class ContactManagementSystem {
    private TreeNode root;

    // Add a contact to the BST
    public void addContact(String name, String phoneNumber, String email) {
        Contact newContact = new Contact(name, phoneNumber, email);
        root = insert(root, newContact);
        System.out.println("Contact added successfully!\n");
    }

    // Helper method to insert a contact into the BST
    private TreeNode insert(TreeNode root, Contact contact) {
        if (root == null) {
            return new TreeNode(contact);
        }
        if (contact.name.compareToIgnoreCase(root.contact.name) < 0) {
            root.left = insert(root.left, contact);
        } else {
            root.right = insert(root.right, contact);
        }
        return root;
    }

    // Search for a contact by name
    public void searchContact(String name) {
        TreeNode result = search(root, name);
        if (result != null) {
            System.out.println("Contact Found: " + result.contact);
        } else {
            System.out.println("Contact not found!");
        }
    }

    // Helper method to search in the BST
    private TreeNode search(TreeNode root, String name) {
        if (root == null || root.contact.name.equalsIgnoreCase(name)) {
            return root;
        }
        if (name.compareToIgnoreCase(root.contact.name) < 0) {
            return search(root.left, name);
        }
        return search(root.right, name);
    }

    // Delete a contact from the BST
    public void deleteContact(String name) {
        root = delete(root, name);
        System.out.println("Contact deleted successfully!\n");
    }

    // Helper method to delete a contact in the BST
    private TreeNode delete(TreeNode root, String name) {
        if (root == null) return null;
        if (name.compareToIgnoreCase(root.contact.name) < 0) {
            root.left = delete(root.left, name);
        } else if (name.compareToIgnoreCase(root.contact.name) > 0) {
            root.right = delete(root.right, name);
        } else {
            if (root.left == null) return root.right;
            if (root.right == null) return root.left;
            TreeNode minNode = findMin(root.right);
            root.contact = minNode.contact;
            root.right = delete(root.right, minNode.contact.name);
        }
        return root;
    }

    // Find the minimum value node in the BST
    private TreeNode findMin(TreeNode root) {
        while (root.left != null) {
            root = root.left;
        }
        return root;
    }

    // Display all contacts in sorted order
    public void displayContacts() {
        if (root == null) {
            System.out.println("No contacts to display.");
        } else {
            System.out.println("All Contacts (Sorted):");
            inOrderTraversal(root);
        }
    }

    // In-order traversal to display contacts in alphabetical order
    private void inOrderTraversal(TreeNode root) {
        if (root != null) {
            inOrderTraversal(root.left);
            System.out.println(root.contact);
            inOrderTraversal(root.right);
        }
    }

    // Main method with menu-driven interface
    public static void main(String[] args) {
        ContactManagementSystem cms = new ContactManagementSystem();
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\nContact Management System");
            System.out.println("1. Add Contact");
            System.out.println("2. Search Contact");
            System.out.println("3. Delete Contact");
            System.out.println("4. Display All Contacts");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1 -> {
                    System.out.print("Enter Name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter Phone Number: ");
                    String phone = scanner.nextLine();
                    System.out.print("Enter Email: ");
                    String email = scanner.nextLine();
                    cms.addContact(name, phone, email);
                }
                case 2 -> {
                    System.out.print("Enter Name to Search: ");
                    String name = scanner.nextLine();
                    cms.searchContact(name);
                }
                case 3 -> {
                    System.out.print("Enter Name to Delete: ");
                    String name = scanner.nextLine();
                    cms.deleteContact(name);
                }
                case 4 -> cms.displayContacts();
                case 5 -> System.out.println("Exiting... Goodbye!");
                default -> System.out.println("Invalid choice! Please try again.");
            }
        } while (choice != 5);
    }
}
